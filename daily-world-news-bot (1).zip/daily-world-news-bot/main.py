import os
import re
import json
import html
import logging
from datetime import datetime, timedelta, timezone
from difflib import SequenceMatcher

import requests
import feedparser

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")

FEEDS = {
    "The New York Times": "https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml",
    "BBC News": "https://feeds.bbci.co.uk/news/rss.xml",
    "Al Jazeera": "https://www.aljazeera.com/xml/rss/all.xml",
}
MAX_STORIES = 5
LOOKBACK_HOURS = 48
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")


def clean_text(value):
    value = re.sub(r"<[^>]+>", " ", value or "")
    return re.sub(r"\s+", " ", html.unescape(value)).strip()


def item_datetime(item):
    for key in ("published_parsed", "updated_parsed", "created_parsed"):
        parsed = item.get(key)
        if parsed:
            try:
                import calendar
                return datetime.fromtimestamp(calendar.timegm(parsed), tz=timezone.utc)
            except (ValueError, OverflowError):
                pass
    return None


def fetch_stories():
    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(hours=LOOKBACK_HOURS)
    stories = []

    for source, url in FEEDS.items():
        logging.info("Reading %s", source)
        try:
            response = requests.get(
                url,
                timeout=25,
                headers={"User-Agent": "DailyWorldNewsBot/1.0 (RSS reader)"}
            )
            response.raise_for_status()
            feed = feedparser.parse(response.content)
            for entry in feed.entries[:25]:
                title = clean_text(entry.get("title", ""))
                link = entry.get("link", "")
                summary = clean_text(entry.get("summary", entry.get("description", "")))
                published = item_datetime(entry)

                if not title or not link:
                    continue
                if published and published < cutoff:
                    continue

                stories.append({
                    "source": source,
                    "title": title,
                    "link": link,
                    "description": summary[:1200],
                    "published": published,
                })
        except Exception as exc:
            logging.warning("Could not read %s: %s", source, exc)

    # Remove duplicate or near-identical headlines.
    unique = []
    for story in sorted(
        stories,
        key=lambda x: x["published"] or datetime.min.replace(tzinfo=timezone.utc),
        reverse=True
    ):
        normalized = re.sub(r"[^a-z0-9 ]", "", story["title"].lower())
        duplicate = False
        for old in unique:
            old_norm = re.sub(r"[^a-z0-9 ]", "", old["title"].lower())
            if normalized == old_norm or SequenceMatcher(None, normalized, old_norm).ratio() > 0.90:
                duplicate = True
                break
        if not duplicate:
            unique.append(story)

    # If all feeds only provide undated/older entries, use the available feed entries.
    if not unique:
        logging.warning("No recent items found; trying the feeds without the date filter.")
        for source, url in FEEDS.items():
            try:
                feed = feedparser.parse(requests.get(url, timeout=25).content)
                for entry in feed.entries[:10]:
                    title = clean_text(entry.get("title", ""))
                    link = entry.get("link", "")
                    if title and link:
                        unique.append({
                            "source": source,
                            "title": title,
                            "link": link,
                            "description": clean_text(entry.get("summary", ""))[:1200],
                            "published": item_datetime(entry),
                        })
            except Exception as exc:
                logging.warning("Fallback failed for %s: %s", source, exc)

    return unique


IMPORTANT_TERMS = {
    "war": 5, "attack": 4, "ceasefire": 5, "election": 4, "president": 3,
    "prime minister": 3, "government": 2, "earthquake": 5, "flood": 4,
    "storm": 3, "climate": 2, "economy": 3, "inflation": 3, "market": 2,
    "sanction": 3, "court": 2, "technology": 2, "artificial intelligence": 2,
    "health": 2, "global": 1, "international": 1
}


def importance_score(story):
    text = (story["title"] + " " + story["description"]).lower()
    score = sum(weight for term, weight in IMPORTANT_TERMS.items() if term in text)
    if story["published"]:
        age_hours = max(0, (datetime.now(timezone.utc) - story["published"]).total_seconds() / 3600)
        score += max(0, 4 - age_hours / 12)
    if story["description"]:
        score += 1
    return score


def choose_top_stories(stories):
    ranked = sorted(stories, key=importance_score, reverse=True)
    chosen = []
    source_counts = {}

    # First pass: encourage a mix of the three publishers.
    for story in ranked:
        source = story["source"]
        if source_counts.get(source, 0) < 2:
            chosen.append(story)
            source_counts[source] = source_counts.get(source, 0) + 1
        if len(chosen) == MAX_STORIES:
            break

    # Second pass: fill any remaining slots.
    if len(chosen) < MAX_STORIES:
        for story in ranked:
            if story not in chosen:
                chosen.append(story)
            if len(chosen) == MAX_STORIES:
                break
    return chosen


def gemini_summaries(stories):
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        logging.info("No Gemini key set; using RSS descriptions as summaries.")
        return None

    numbered = []
    for index, story in enumerate(stories, start=1):
        numbered.append(
            f"{index}. HEADLINE: {story['title']}\n"
            f"SOURCE: {story['source']}\n"
            f"RSS DESCRIPTION: {story['description'] or '(not provided)'}"
        )

    prompt = (
        "You are a careful international news editor. Use ONLY the headline and RSS "
        "description supplied below. Do not add facts, dates, causes, numbers, quotes, "
        "or context that are not present. If information is insufficient, say so briefly. "
        "For each numbered story, write a neutral English summary of 1-2 short sentences, "
        "maximum 45 words. Return ONLY valid JSON in this exact shape: "
        '{"summaries":[{"id":1,"summary":"..."}]}. Do not write article text or imitate '
        "the publisher's style.\n\n" + "\n\n".join(numbered)
    )

    endpoint = (
        f"https://generativelanguage.googleapis.com/v1beta/models/"
        f"{GEMINI_MODEL}:generateContent?key={api_key}"
    )
    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.2, "maxOutputTokens": 1200}
    }

    try:
        response = requests.post(endpoint, json=payload, timeout=45)
        response.raise_for_status()
        data = response.json()
        raw = data["candidates"][0]["content"]["parts"][0]["text"]
        raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw.strip(), flags=re.I)
        parsed = json.loads(raw)
        result = {}
        for item in parsed.get("summaries", []):
            result[int(item["id"])] = clean_text(item["summary"])
        return result
    except Exception as exc:
        logging.warning("Gemini unavailable; falling back to RSS descriptions: %s", exc)
        return None


def make_message(stories, summaries):
    today = datetime.now(timezone.utc).strftime("%d %B %Y")
    lines = [
        "🌍 <b>DAILY WORLD NEWS</b>",
        f"<i>{today} · Top 5 stories</i>",
        ""
    ]

    for index, story in enumerate(stories, start=1):
        summary = (summaries or {}).get(index)
        if not summary:
            summary = story["description"] or "The RSS feed did not provide a summary. Open the original report for details."
        summary = summary[:500].rstrip()
        title = html.escape(story["title"])
        source = html.escape(story["source"])
        link = html.escape(story["link"], quote=True)
        lines.extend([
            f"<b>{index}. {title}</b>",
            html.escape(summary),
            f"<i>Source: {source}</i> · <a href=\"{link}\">Read original</a>",
            ""
        ])

    lines.append("<i>Summaries are based on publisher RSS headlines/descriptions. Follow the source link for full reporting.</i>")
    message = "\n".join(lines)
    if len(message) > 3900:
        message = message[:3800] + "\n\n<i>Message shortened to fit Telegram.</i>"
    return message


def send_telegram(message):
    token = os.environ["TELEGRAM_BOT_TOKEN"]
    chat_id = os.environ["TELEGRAM_CHAT_ID"]
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    response = requests.post(url, json={
        "chat_id": chat_id,
        "text": message,
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }, timeout=30)
    response.raise_for_status()
    result = response.json()
    if not result.get("ok"):
        raise RuntimeError(f"Telegram API error: {result}")
    logging.info("Telegram message sent successfully.")


def main():
    stories = fetch_stories()
    if not stories:
        raise RuntimeError("No news items could be fetched from the RSS feeds.")

    selected = choose_top_stories(stories)
    summaries = gemini_summaries(selected)
    message = make_message(selected, summaries)
    send_telegram(message)


if __name__ == "__main__":
    main()

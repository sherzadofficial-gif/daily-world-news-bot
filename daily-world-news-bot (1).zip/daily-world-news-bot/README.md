# Daily World News Bot

A small Python + GitHub Actions project that reads public RSS feeds from The New York Times, BBC News and Al Jazeera, selects five recent stories, optionally summarizes them with Gemini, and sends one digest to Telegram every day.

## What it does

- Runs every day at 08:00 Türkiye time (05:00 UTC).
- Reads public RSS headlines and descriptions; it does not copy full articles.
- Removes near-duplicate headlines and selects up to five stories.
- Uses Gemini if `GEMINI_API_KEY` is configured. If not, it uses the RSS descriptions as summaries.
- Sends links to the original publishers.

## Setup

1. Create a Telegram bot with `@BotFather` and copy its token.
2. Create a Telegram channel and add the bot as an administrator with permission to post.
3. Get the channel ID. For a public channel, `@your_channel_username` can be used as `TELEGRAM_CHAT_ID`. For a private channel, use its numeric chat ID (often starts with `-100`).
4. Create a public GitHub repository and upload these files, keeping `.github/workflows/daily-news.yml` at exactly that path.
5. In GitHub, open **Settings → Secrets and variables → Actions → New repository secret**. Add:
   - `TELEGRAM_BOT_TOKEN`
   - `TELEGRAM_CHAT_ID`
   - `GEMINI_API_KEY` (optional; omit for RSS-description fallback)
6. Open **Actions → Daily World News → Run workflow** to test it manually.
7. Check the Telegram channel. If the test succeeds, the daily schedule is enabled.

## Free-tier note

GitHub Actions standard runners are free for public repositories. Gemini has a free tier for eligible models/accounts, but quotas and model availability can change. If the Gemini key is absent or the API call fails, the bot falls back to the RSS descriptions and does not need an AI API.

## Important notes

- GitHub scheduled jobs can start a little later than the exact scheduled minute.
- Do not publish your bot token or Gemini API key. Store them only as GitHub Actions secrets.
- NYT articles may require a subscription. The bot sends the public RSS headline/description and the publisher's original link.
- Publisher feeds and availability can change; a failed feed is logged and the other feeds are still checked.
- This is a news digest, not a substitute for reading and verifying the original reporting.
